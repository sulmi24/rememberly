import { supabase } from './supabase';

export async function signUp(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  return { data, error };
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  return { error };
}

export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  
  // Handle stale JWT session error
  if (error && error.message === 'Session from session_id claim in JWT does not exist') {
    // Clear the invalid session
    await supabase.auth.signOut();
    return { user: null, error: null };
  }
  
  return { user, error };
}